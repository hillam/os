/*------------------------------------------------------------------------------
	Matrix Multiplication 
------------------------------------------------------------------------------*/

// use one thread for each resultant number in a resultant mamtrix

// the resulting matrix of the dot product of a 2x3 matrix and a 3x2 matrix 
// will be 2x2, so it will use 4 threads

// 3 files..
// matrix class for reading and writing matrix with header
// main.cpp